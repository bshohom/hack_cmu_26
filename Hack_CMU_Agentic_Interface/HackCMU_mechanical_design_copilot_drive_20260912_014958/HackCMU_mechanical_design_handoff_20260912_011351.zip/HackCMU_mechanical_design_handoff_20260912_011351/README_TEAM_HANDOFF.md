# HackCMU Mechanical Design Copilot — Team Handoff Guide

## 1. Purpose

This package is the integration handoff for the current HackCMU mechanical-design prototype. The key design principle is that every teammate produces a typed output that matches the existing shared schema. The orchestrator should not be rewritten to fit a teammate's implementation.

**Contract rule:**

`Aman implementation -> RegistrationOutput`

`Yujie implementation -> GeometryOutput`

`Shohom implementation -> TopologyOutput`

If those contracts are satisfied, each mock component can be replaced by the real component without changing the overall workflow.

## 2. Current workflow

`User image + request -> live Cursor scene reasoning -> clarification -> DesignState -> Registration -> Geometry -> Structure -> Analysis -> Topology Optimization -> Verification -> CAD output`

Current custom-user defaults:

- Reasoning provider: **Cursor**, when `CURSOR_API_KEY` is available; otherwise Mock fallback.
- Cursor model: **gpt-5.6-sol**, context `272k`, reasoning `high`, fast `false`.
- Geometry source: **Adaptive Synthetic Mock**.
- Registration: Mock.
- Structure: current integration/StructureAgent implementation.
- Analysis/FEM: Mock.
- Topology optimization: Mock.
- Verification: real orchestration/artifact check, but physical safety remains unverified whenever mock engineering evidence is present.
- CAD/STL: Mock output hook; no real printable CAD is generated yet.

`Load Happy Path` intentionally switches Geometry to the fixed Golden Fixture so the deterministic integration example can be replayed.

## 3. What has actually been demonstrated

The current live front end can accept a desk/bottle image and a free-form request. Cursor/GPT-5.6 can return a structured scene observation containing the payload, support environment, plausible attachment concepts, missing measurements, uncertainty, and confidence. Inferred image values are not silently promoted into authoritative engineering requirements.

The downstream integration pipeline can then run with adaptive synthetic geometry derived from user-entered dimensions. This demonstrates software integration and information flow. It does **not** mean that the image has been reconstructed into engineering geometry, FEM has been performed, topology optimization has been run, or a printable STL has been generated.

## 4. Quick start

From the project root:

```bash
cd /Users/chanisong/Desktop/2026_HackCMU/260911
source .venv/bin/activate
python -m streamlit run app.py --server.port 8503
```

The project `.env` may contain a local Cursor key:

```text
CURSOR_API_KEY=...
```

The `.env` file must **not** be included in the team handoff archive. `.env.example` may be shared.

Useful regression commands:

```bash
python3 test_workflow.py
python3 test_fixtures.py
python3 test_geometry_sources.py
python3 test_ui_state.py
# If using Python 3.12 / Cursor SDK:
python test_cursor_adapter.py
```

## 5. Files teammates should read first

1. `schemas.py` — authoritative typed interfaces.
2. `state.py` — shared `DesignState`.
3. `orchestrator.py` — deterministic workflow transitions and consistency checks.
4. `examples/cup_holder/*.json` — concrete interface examples.
5. `app.py` — UI and live/mock component selection.

The most important rule is: **do not modify the orchestrator merely to make a teammate implementation fit. Adapt the teammate implementation to the existing typed output contract.** If the current contract is truly insufficient, discuss the schema change with the team before changing it.

---

# 6. Aman — Registration interface

### Goal

Convert image/scan/point information into a declared common coordinate frame that downstream geometry can use.

### Expected logical input

- User image / scan / point data.
- Any calibration/reference information used by the registration method.
- Resolved mounting context when needed.

### Required output

Return the existing `RegistrationOutput` defined in `schemas.py`. Use `examples/cup_holder/02_registration_output.json` as the concrete reference.

The output should communicate, at minimum:

- a stable `frame_id` for the common coordinate frame;
- the registration / transform information needed to express downstream geometry in that frame;
- confidence/quality metadata if supported;
- `is_mock = false` for the real implementation.

### Integration requirement

Yujie's real geometry must declare the same common frame. Do not send only prose such as "aligned successfully"; provide structured transform/frame data that can be checked by the pipeline.

### Suggested deliverables

```text
registration_output.json
# optional additional calibration / transform artifacts if needed
```

---

# 7. Yujie — Geometry interface

### Goal

Produce downstream-usable engineering geometry and semantic regions, expressed in Aman's common coordinate frame.

### Expected logical input

- `RegistrationOutput` from Aman.
- User image / scan / point representation.
- Resolved user requirements and measurements.

### Required output

Return the existing `GeometryOutput` defined in `schemas.py`. Use `examples/cup_holder/03_geometry_output.json` as the concrete reference.

The output should distinguish:

- environment/support geometry (desk, wall, mount surface, etc.);
- payload/object geometry (bottle, object being supported, etc.);
- attachment/contact regions;
- load-application/support regions;
- design envelope / allowable design region;
- common `frame_id` matching Aman's registration;
- `is_mock = false` for the real implementation.

Do not silently overwrite explicit user measurements when reconstructed geometry disagrees with them. The integration layer intentionally blocks such conflicts.

### Preferred file form

A JSON contract plus actual geometry files referenced by the JSON is easiest to integrate, for example:

```text
geometry_output.json
environment_mesh.stl      # or OBJ / other agreed format
payload_mesh.stl          # or OBJ / other agreed format
# optional point cloud / region mask files
```

The JSON should contain stable references/paths/IDs for any external geometry artifact.

---

# 8. Shohom — Topology optimization interface

### Goal

Consume the agreed design domain and structural loading/boundary-condition information, then return an optimized structural representation that can be traced back to the exact source problem.

### Expected logical input

- design domain / geometry;
- attachment/fixed regions;
- load-application regions;
- load case and force information;
- material / manufacturing or optimization constraints as agreed;
- analysis information if the method requires it.

### Required output

Return the existing `TopologyOutput` defined in `schemas.py`. Use `examples/cup_holder/06_topology_output.json` as the concrete reference.

The output should preserve provenance, especially which structural/load case was optimized. Prefer fields/artifacts that make the following traceable:

- source load-case ID / structural problem identity;
- optimized geometry reference;
- density field or mesh if available;
- volume fraction;
- objective/compliance or equivalent metric if available;
- solver/convergence status if available;
- `is_mock = false` for the real implementation.

### Preferred file form

```text
topology_output.json
optimized_topology.stl    # if a mesh can be exported
# optional density field / voxel / point representation
```

A real optimized mesh is preferable to a JSON field that merely claims a mesh exists.

---

# 9. Interface integration procedure

For each teammate implementation:

1. Keep the existing output schema.
2. Create one deterministic cup-holder test output first.
3. Validate it with the corresponding Pydantic model.
4. Replace only that component's Mock/Fixture path with the real implementation.
5. Run the existing regression tests.
6. Verify the UI clearly marks the component as LIVE rather than MOCK.
7. Check that downstream stages receive exactly the same typed structure they previously received from the fixture.

Do not remove consistency checks just because a real component returns conflicting values. A conflict should be surfaced explicitly.

## 10. Current real vs mock status

| Stage | Current status | Interpretation |
|---|---|---|
| Image/scene understanding | LIVE when Cursor key is available | GPT-5.6 reads the uploaded image and returns structured `SceneObservation` |
| Requirements/clarification | OURS / LIVE logic | User measurements become authoritative requirements |
| Registration | MOCK | Common frame is currently assumed by fixture |
| Geometry | Adaptive Synthetic Mock by default | Primitive geometry is generated from user-entered dimensions; image is not reconstructed |
| Structure | OURS | Coarse nodes/members/load path are generated |
| Analysis/FEM | MOCK | Numeric outputs are placeholders and must not be interpreted physically |
| Topology optimization | MOCK | Placeholder interface only; no real optimization mesh yet |
| Verification | OURS | Checks artifact completion / safety flags; mock evidence keeps safety UNVERIFIED |
| CAD/STL | MOCK | Output hook only; no real printable file on disk yet |

## 11. Known limitations / important interpretation

- `COMPLETE` currently means the integration pipeline has produced all required software artifacts. It does **not** mean the physical design has been validated.
- Any workflow containing mock FEM or mock topology remains `PHYSICAL SAFETY: UNVERIFIED`.
- Adaptive Synthetic Geometry is not image reconstruction.
- Current `SceneObservation` is live and useful, but the core `InteractionAgent` still owns the minimum required clarification set.
- Physical/geometric feasibility gates are still limited. For example, obviously incompatible requirements should eventually be rejected before structural analysis rather than merely passing schema validation.

## 12. Package contents to share

The recommended handoff archive contains:

```text
app.py
orchestrator.py
schemas.py
state.py
reasoning.py
providers.py
ui_inspect.py
ui_viz.py
main.py
requirements.txt
.env.example

agents/
tools/
examples/cup_holder/

demo_fixture_workflow.py
test_workflow.py
test_fixtures.py
test_geometry_sources.py
test_ui_state.py
test_cursor_adapter.py

README_TEAM_HANDOFF.md
TEAM_HANDOFF_GUIDE.docx
TEAM_MESSAGE.txt
```

The archive must exclude:

```text
.env
.venv/
.git/
__pycache__/
*.pyc
.streamlit/
```

