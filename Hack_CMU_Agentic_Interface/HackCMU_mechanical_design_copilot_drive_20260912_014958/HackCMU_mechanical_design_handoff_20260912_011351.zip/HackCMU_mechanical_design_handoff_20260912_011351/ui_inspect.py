"""Format DesignState for the workflow inspect panels. Display only."""

from __future__ import annotations

from typing import Any, Dict, List

from schemas import WorkflowStage
from state import DesignState

PIPELINE = [
    "REQUIREMENTS",
    "REGISTRATION",
    "GEOMETRY",
    "STRUCTURE",
    "ANALYSIS",
    "TOPOLOGY OPTIMIZATION",
    "VERIFICATION",
    "CAD OUTPUT",
]


def _artifact_badge(is_mock: bool) -> str:
    return "MOCK" if is_mock else "LIVE"


def highlighted_stage(state: DesignState) -> str:
    """Which pipeline card to emphasize. Display-only; not a transition."""
    stage = state.stage
    if stage in (WorkflowStage.REQUIREMENTS, WorkflowStage.REQUEST_INFORMATION, WorkflowStage.REJECTED):
        return "REQUIREMENTS"
    if stage == WorkflowStage.GEOMETRY:
        return "REGISTRATION" if state.registration is None else "GEOMETRY"
    if stage == WorkflowStage.STRUCTURE:
        return "STRUCTURE"
    if stage == WorkflowStage.ANALYSIS:
        return "ANALYSIS"
    if stage == WorkflowStage.TOPOLOGY_OPTIMIZATION:
        return "TOPOLOGY OPTIMIZATION"
    if stage == WorkflowStage.VERIFICATION:
        return "VERIFICATION"
    if stage == WorkflowStage.COMPLETE:
        return "CAD OUTPUT"
    return "REQUIREMENTS"


def pipeline_status(state: DesignState) -> Dict[str, str]:
    """Derive display badges from backend state. Does not decide transitions."""
    status = {name: "NOT STARTED" for name in PIPELINE}
    stage = state.stage

    if stage == WorkflowStage.REJECTED:
        status["REQUIREMENTS"] = "REJECTED"
        return status

    if stage == WorkflowStage.REQUEST_INFORMATION:
        status["REQUIREMENTS"] = "WAITING FOR INPUT"
        return status

    if state.requirements is not None:
        status["REQUIREMENTS"] = "COMPLETE"

    if state.registration is not None:
        status["REGISTRATION"] = _artifact_badge(state.registration.is_mock)
    if state.geometry is not None:
        status["GEOMETRY"] = _artifact_badge(state.geometry.is_mock)
    if state.structure is not None:
        status["STRUCTURE"] = "COMPLETE"
    if state.analysis is not None:
        status["ANALYSIS"] = _artifact_badge(state.analysis.is_mock)
    if state.topology is not None:
        status["TOPOLOGY OPTIMIZATION"] = _artifact_badge(state.topology.is_mock)
    if state.verification is not None:
        status["VERIFICATION"] = (
            "COMPLETE" if state.verification.artifacts_complete else "BLOCKED"
        )
    if state.cad is not None:
        status["CAD OUTPUT"] = _artifact_badge(state.cad.is_mock)
    elif stage == WorkflowStage.COMPLETE:
        status["CAD OUTPUT"] = "COMPLETE"

    if state.contract_error:
        current = highlighted_stage(state)
        status[current] = "BLOCKED"
    return status


def engineering_evidence_is_mocked(state: DesignState) -> bool:
    if state.analysis is not None and state.analysis.is_mock:
        return True
    if state.topology is not None and state.topology.is_mock:
        return True
    if state.cad is not None and state.cad.is_mock:
        return True
    if state.verification is not None and (
        state.verification.analysis_is_mock or state.verification.topology_is_mock
    ):
        return True
    return False


def inspect_cards(state: DesignState) -> List[Dict[str, Any]]:
    cards: List[Dict[str, Any]] = []
    if state.requirements is not None:
        req = state.requirements
        cards.append(
            {
                "title": "REQUIREMENTS",
                "owner": "Our system — InteractionAgent",
                "input_schema": "user message (str)",
                "input": {"user_message": req.user_message},
                "output_schema": "UserRequirements + InteractionDecision",
                "output": {
                    "decision": state.interaction_decision.value
                    if state.interaction_decision
                    else None,
                    "payload_mass_kg": req.payload.filled_mass_kg,
                    "bottle_diameter_mm": req.object_geometry.bottle_diameter_mm,
                    "desk_thickness_mm": req.environment.desk_thickness_mm,
                    "attachment": req.attachment.method,
                    "max_protrusion_mm": req.design_envelope.max_protrusion_mm,
                    "manufacturing": req.manufacturing.method,
                },
                "is_mock": False,
                "provenance": None,
            }
        )
    if state.registration is not None:
        reg = state.registration
        cards.append(
            {
                "title": "REGISTRATION",
                "owner": "Aman",
                "input_schema": "GeometryInput.image_paths / point clouds",
                "input": {"photo": "uploaded image is not consumed by registration yet"},
                "output_schema": "RegistrationOutput",
                "output": {
                    "frame_id": reg.frame_id,
                    "confidence": reg.confidence,
                    "is_mock": reg.is_mock,
                },
                "is_mock": reg.is_mock,
                "provenance": "mock fixture" if reg.is_mock else "live",
            }
        )
    if state.geometry is not None:
        geom = state.geometry
        cards.append(
            {
                "title": "GEOMETRY",
                "owner": (
                    "Yujie"
                    if "Yujie" in (geom.notes or "")
                    else "Our system — GeometryAgent"
                ),
                "input_schema": "GeometryInput",
                "input": {
                    "coordinate_frame": geom.coordinate_frame,
                    "from_requirements": True,
                },
                "output_schema": "GeometryOutput",
                "output": {
                    "payload": geom.payload_object.kind,
                    "diameter_mm": geom.payload_object.bottle_diameter_mm,
                    "desk_thickness_mm": geom.environment.desk_thickness_mm,
                    "protrusion_mm": geom.design_envelope.max_protrusion_mm,
                    "part_estimated_mass_kg": geom.part.estimated_mass_kg,
                    "is_mock": geom.is_mock,
                },
                "is_mock": geom.is_mock,
                "provenance": geom.notes or ("mock fixture" if geom.is_mock else "live"),
            }
        )
    if state.structure is not None:
        structure = state.structure
        load = structure.load_cases[0] if structure.load_cases else None
        cards.append(
            {
                "title": "STRUCTURE",
                "owner": "Our system — StructureAgent",
                "input_schema": "StructureInput",
                "input": {
                    "payload_mass_kg": (
                        state.resolved_payload_mass.mass_kg
                        if state.resolved_payload_mass
                        else None
                    ),
                    "provenance": (
                        state.resolved_payload_mass.provenance.value
                        if state.resolved_payload_mass
                        else None
                    ),
                },
                "output_schema": "StructureOutput",
                "output": {
                    "concept": structure.concept,
                    "nodes": len(structure.nodes),
                    "members": len(structure.members),
                    "load_case_id": load.load_case_id if load else None,
                    "force_N": load.force_N if load else None,
                },
                "is_mock": False,
                "provenance": (
                    state.resolved_payload_mass.notes
                    if state.resolved_payload_mass
                    else None
                ),
            }
        )
    if state.analysis is not None:
        analysis = state.analysis
        cards.append(
            {
                "title": "ANALYSIS",
                "owner": "Analysis tool / fixture",
                "input_schema": "AnalysisInput",
                "input": {
                    "load_case_id": analysis.load_case_id,
                    "load_force_N": analysis.load_force_N,
                },
                "output_schema": "AnalysisOutput",
                "output": {
                    "is_mock": analysis.is_mock,
                    "max_stress_pa": analysis.max_stress_pa,
                    "max_displacement_mm": analysis.max_displacement_mm,
                    "factor_of_safety": analysis.factor_of_safety,
                    "is_safety_validation": analysis.is_safety_validation,
                },
                "is_mock": analysis.is_mock,
                "provenance": analysis.solver,
            }
        )
    if state.topology is not None:
        topology = state.topology
        cards.append(
            {
                "title": "TOPOLOGY OPTIMIZATION",
                "owner": "Shohom",
                "input_schema": "TopologyInput",
                "input": {"design_domain": "GeometryOutput.part"},
                "output_schema": "TopologyOutput",
                "output": {
                    "is_mock": topology.is_mock,
                    "volume_fraction": topology.volume_fraction,
                    "mass_reduction_pct": topology.mass_reduction_pct,
                    "geometry_ref": topology.optimized_geometry_ref,
                    "model": topology.model,
                },
                "is_mock": topology.is_mock,
                "provenance": "mock fixture" if topology.is_mock else "live",
            }
        )
    if state.verification is not None:
        ver = state.verification
        cards.append(
            {
                "title": "VERIFICATION",
                "owner": "Our system",
                "input_schema": "DesignState artifacts",
                "input": {
                    "geometry": state.geometry is not None,
                    "structure": state.structure is not None,
                    "analysis": state.analysis is not None,
                    "topology": state.topology is not None,
                },
                "output_schema": "VerificationResult",
                "output": {
                    "artifacts_complete": ver.artifacts_complete,
                    "safety_validated": ver.safety_validated,
                    "safety_status": state.safety_status.value,
                    "notes": ver.notes,
                },
                "is_mock": ver.analysis_is_mock or ver.topology_is_mock,
                "provenance": None,
            }
        )
    if state.cad is not None:
        cad = state.cad
        cards.append(
            {
                "title": "CAD OUTPUT",
                "owner": "CAD tool / fixture",
                "input_schema": "CadInput",
                "input": {"geometry": True, "topology": True},
                "output_schema": "CadOutput",
                "output": {
                    "filename": cad.filename,
                    "format": cad.format,
                    "is_mock": cad.is_mock,
                    "stl_hook": "Display STL/OBJ here when a real path exists.",
                },
                "is_mock": cad.is_mock,
                "provenance": cad.notes,
            }
        )
    return cards
