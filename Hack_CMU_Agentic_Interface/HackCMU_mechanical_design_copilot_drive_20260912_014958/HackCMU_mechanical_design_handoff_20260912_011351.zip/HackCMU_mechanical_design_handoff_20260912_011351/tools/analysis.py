"""Deterministic structural analysis tool (mock FEM).

The LLM constructs the AnalysisInput. This tool returns typed results.
It must never be treated as safety validation.
"""

from __future__ import annotations

from schemas import AnalysisInput, AnalysisOutput


def run_analysis(inp: AnalysisInput) -> AnalysisOutput:
    """Return simulated placeholder numbers. is_mock is always True."""
    mag = sum(x * x for x in inp.load_force_N) ** 0.5
    reactions = [tuple(-x for x in inp.load_force_N)]

    max_stress = mag * 12.0
    max_disp = mag * 0.002

    return AnalysisOutput(
        load_case_id=inp.load_case_id,
        load_force_N=inp.load_force_N,
        is_mock=True,
        max_displacement_mm=max_disp,
        max_stress_pa=max_stress,
        factor_of_safety=None,
        reaction_forces_N=reactions,
        is_safety_validation=False,
        solver="mock-fem-simulated",
        solver_status="simulated_only",
        disclaimer=(
            "SIMULATED placeholder results. Not real FEM. "
            "Do not treat as engineering validation."
        ),
    )
